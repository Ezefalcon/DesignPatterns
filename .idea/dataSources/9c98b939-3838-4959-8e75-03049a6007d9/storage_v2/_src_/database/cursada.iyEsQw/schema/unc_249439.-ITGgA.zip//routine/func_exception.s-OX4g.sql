create function func_exception() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE EXCEPTION 'No puede haber mas de 10 alquiler como posiciones';
END;
$$;

alter function func_exception() owner to unc_249439;

